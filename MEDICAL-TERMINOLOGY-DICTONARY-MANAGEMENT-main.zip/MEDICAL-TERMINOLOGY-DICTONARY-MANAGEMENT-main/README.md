# MEDICAL-TERMINOLOGY-DICTONARY-MANAGEMENT
Medical terminology dictionary management involves the organization, maintenance, and updating of a comprehensive dictionary of medical terms used in the healthcare field  .
